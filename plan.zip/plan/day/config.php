<?php
define('SQL_HOST',     'localhost');
define('SQL_USER',     'srv93195_away');
define('SQL_PASSWD',   'away_1985');
define('SQL_DATABASE', 'srv93195_msg');
define('SQL_PREFIX',   'phpc_');
define('SQL_TYPE',     'mysqli');
?>
